const burgerBtn = document.querySelector('.burger__icons')
const burgerLinks = document.querySelector('.burger__links')

burgerBtn.addEventListener('click', function() {
    burgerLinks.classList.toggle('active__burger')
})

const introBtn = document.querySelector('.option__PS')
const backCircleBlue = document.querySelector('.circle__one')
const backCirclePurple = document.querySelector('.circle__two')

introBtn.addEventListener('click', function() {
    backCircleBlue.classList.toggle('active__circle')
    backCirclePurple.classList.toggle('active__circle')
})


const greenBtn = document.querySelector('.option__UX')
const backCircleGreen = document.querySelector('.circle__three')

greenBtn.addEventListener('click', function() {
    backCircleBlue.classList.toggle('active__circle')
    backCircleGreen.classList.toggle('active__circle')
})


